package com.example.demo;

import org.junit.jupiter.api.Test;

public class DemoControllerTests {
    @Test
    void testDetail() {

    }

    @Test
    void testGetApidata() {

    }

    @Test
    void testMain() {
        
    }
}
